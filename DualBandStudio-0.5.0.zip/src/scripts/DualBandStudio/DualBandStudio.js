// DualBand Studio — Copyright (c) 2026 Kuba Winkler. <license name>
//
// Entry point: header directives, #includes, main().

#feature-id    Utilities > DualBandStudio
#feature-info  Dual-band OSC narrowband extraction, palette mixer and colour tools. Written by Kuba Winkler.
#script-id     DualBandStudio

#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ColorSpace.jsh>

#include "lib/version.js"
#include "lib/core/extract.js"
#include "lib/core/stretch.js"
#include "lib/core/mixer.js"
#include "lib/core/hsi.js"
#include "lib/core/color.js"
#include "lib/core/stars.js"
#include "lib/core/presets.js"
#include "lib/pi/io.js"
#include "lib/pi/extract.js"
#include "lib/pi/preview.js"
#include "lib/pi/apply.js"
#include "lib/pi/stars.js"
#include "lib/ui/widgets.js"
#include "lib/ui/previewControl.js"
#include "lib/ui/dialog.js"

// Runs extraction without the dialog (process icon dropped on a view, or executed globally).
function dbsRunHeadless(viewA, imported)
{
   var viewB = imported.idB ? View.viewById(imported.idB) : null;
   if (imported.idB && !dbsViewIsValid(viewB))
      Console.warningln("[DBS] Master B '" + imported.idB + "' not found, extracting without SII.");
   try
   {
      dbsExtract(viewA, viewB, imported.params);
   }
   catch (e)
   {
      Console.criticalln("[DBS] " + e.message);
   }
}

function main()
{
   Console.show();
   Console.writeln("[DBS] " + DBS_TITLE + " v" + DBS_VERSION + " — by " + DBS_AUTHOR);

   var imported = dbsImportParameters();

   if (Parameters.isViewTarget)
   {
      dbsRunHeadless(Parameters.targetView, imported || { params: dbsLoadExtractSettings(), idA: "", idB: "" });
      return;
   }
   if (Parameters.isGlobalTarget)
   {
      if (imported == null || !dbsViewIsValid(View.viewById(imported.idA)))
      {
         Console.criticalln("[DBS] Master A from the process icon is not open. Drop the icon on the Ha+OIII master instead.");
         return;
      }
      dbsRunHeadless(View.viewById(imported.idA), imported);
      return;
   }

   var dialog = new DBSDialog(imported || { params: dbsLoadExtractSettings(), idA: "", idB: "", mix: dbsLoadMixSettings(), color: dbsLoadColorSettings(), stars: dbsLoadStarsSettings() });
   dialog.execute();
   dialog.previewTimer.stop();
}

main();
