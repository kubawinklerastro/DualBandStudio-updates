// DualBand Studio — Copyright (c) 2026 Kuba Winkler. <license name>
//
// Entry point: header directives, #includes, main().

#feature-id    Utilities > DualBandStudio
#feature-info  Dual-band OSC narrowband extraction, palette mixer and colour tools. Written by Kuba Winkler.
#script-id     DualBandStudio

#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

#include "lib/version.js"
#include "lib/core/mixer.js"
#include "lib/core/hsi.js"
#include "lib/core/color.js"
#include "lib/core/presets.js"
#include "lib/pi/io.js"
#include "lib/pi/extract.js"
#include "lib/pi/preview.js"
#include "lib/pi/apply.js"
#include "lib/pi/stars.js"
#include "lib/ui/widgets.js"
#include "lib/ui/previewControl.js"
#include "lib/ui/dialog.js"

function main()
{
   Console.show();
   Console.writeln("[DBS] " + DBS_TITLE + " v" + DBS_VERSION + " — by " + DBS_AUTHOR);
   var dialog = new DBSDialog();
   dialog.execute();
}

main();
